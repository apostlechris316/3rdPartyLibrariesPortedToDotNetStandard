﻿using StandardLibrary.LineCounterEngine;
using System;
using System.IO;

namespace UnitTestLineCounterEngineCoreConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Unit Testing Line Counter Engine!");
            var projectDirectory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory.Replace("UnitTestLineCounterEngineCoreConsole\\bin\\Debug\\netcoreapp2.0", string.Empty));
            var fileSearchPatterns = new String[1];
            fileSearchPatterns[0] = "*.cs";

            var directoryLineCounter = new DirectoryLineCounter(projectDirectory, fileSearchPatterns);
            directoryLineCounter.CountLines();

            Console.WriteLine("Number of files to count: " + directoryLineCounter.FilesToCount());
            Console.WriteLine("Number of lines in directory: " + directoryLineCounter.DirectoryLines);
            Console.WriteLine("SubDirectories - Total Lines: " + directoryLineCounter.SubDirectoriesTotalLines);
            Console.WriteLine("Total Lines: " + directoryLineCounter.TotalLines);

            Console.ReadKey();
        }
    }
}
