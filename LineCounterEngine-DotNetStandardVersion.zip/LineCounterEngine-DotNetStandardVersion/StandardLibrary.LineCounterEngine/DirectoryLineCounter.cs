﻿using System;
using System.Collections;
using System.IO;

namespace StandardLibrary.LineCounterEngine
{
    /// <summary>
    /// Ported from https://www.codeproject.com/Articles/9105/Counting-Lines-of-Code-in-C to .NET Standard Library
    /// </summary>
    public class DirectoryLineCounter : IComparable
    {
        /// <summary>
        /// Array of directories to ignore
        /// </summary>
        public string[] DirectoryIgnoreNames { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="directoryInfo">Directory information for directory containing source</param>
        /// <param name="FileSearchPatterns">Array of search patterns to count</param>
        public DirectoryLineCounter(DirectoryInfo directoryInfo, string[] fileSearchPatterns)
        {
            _directoryInfo = directoryInfo;
            _fileSearchPattern = fileSearchPatterns;
        }

        /// <summary>
        /// Directory Information object used to find code line count
        /// </summary>
        public DirectoryInfo Directory { get { return _directoryInfo; } }
        private DirectoryInfo _directoryInfo = null;

        /// <summary>
        /// Array of search patterns to count
        /// </summary>
        public string [] FileSearchPatterns { get { return _fileSearchPattern; } }
        private string[] _fileSearchPattern = null;

        /// <summary>
        /// 
        /// </summary>
        public bool Recurse = true;

        /// <summary>
        /// 
        /// </summary>
        public int DirectoryLines;

        /// <summary>
        /// 
        /// </summary>
        public int SubDirectoriesTotalLines;

        /// <summary>
        /// 
        /// </summary>
        public int TotalLines { get { return DirectoryLines + SubDirectoriesTotalLines; } }

        /// <summary>
        /// 
        /// </summary>
        public DirectoryLineCounter[] SubDirectoryCounters;

        /// <summary>
        /// 
        /// </summary>
        public event FilesCompletedHandler FilesCompleted;

        /// <summary>
        /// Looks at the directory and gets the number of files to count
        /// </summary>
        /// <returns></returns>
        public int FilesToCount()
        {
            int fileCount = 0;

            // if no file search pattern provided then assume all files
            if (FileSearchPatterns == null)
            {
                fileCount += Directory.GetFiles("*.*").Length;
            }
            else
            {
                foreach (string pattern in FileSearchPatterns)
                {
                    fileCount += Directory.GetFiles(pattern).Length;
                }
            }

            if (Recurse)
            {
                foreach (DirectoryInfo directoryInfo in Directory.GetDirectories())
                {
                    bool searchDirectory = true;
                    if (DirectoryIgnoreNames != null)
                    {
                        foreach (string ignoreName in DirectoryIgnoreNames)
                        {
                            if (directoryInfo.Name.ToLower() == ignoreName.ToLower())
                            {
                                searchDirectory = false;
                                break;
                            }
                        }
                    }

                    if (searchDirectory)
                    {
                        DirectoryLineCounter dlc = new DirectoryLineCounter(directoryInfo, FileSearchPatterns);
                        fileCount += dlc.FilesToCount();
                    }
                }
            }

            return fileCount;
        }

        /// <summary>
        /// Counts the lines 
        /// </summary>
        public void CountLines()
        {
            DirectoryLines = CountLines(this.Directory);
            SubDirectoriesTotalLines = 0;

            if (Recurse)
            {
                ArrayList directoryCounters = new ArrayList();

                foreach (DirectoryInfo directoryInfo in this.Directory.GetDirectories())
                {
                    bool searchDirectory = true;
                    if (DirectoryIgnoreNames != null)
                    {
                        foreach (string ignoreName in DirectoryIgnoreNames)
                        {
                            if (directoryInfo.Name.ToLower() == ignoreName.ToLower())
                            {
                                searchDirectory = false;
                                break;
                            }
                        }
                    }

                    if (searchDirectory)
                    {
                        DirectoryLineCounter dlc = new DirectoryLineCounter(directoryInfo, FileSearchPatterns);
                        dlc.FilesCompleted += new FilesCompletedHandler(dlc_FilesCompleted);
                        dlc.CountLines();
                        directoryCounters.Add(dlc);
                        SubDirectoriesTotalLines += (dlc.SubDirectoriesTotalLines + dlc.DirectoryLines);
                    }
                }

                directoryCounters.Sort();

                SubDirectoryCounters = (DirectoryLineCounter[])directoryCounters.ToArray(typeof(DirectoryLineCounter));
            }
        }

        /// <summary>
        /// Counts the lines for files in a given directory
        /// </summary>
        /// <param name="directoryInfo"></param>
        /// <returns></returns>
        public int CountLines(DirectoryInfo directoryInfo)
        {
            int lines = 0;
            int filesDone = 0;

            foreach (string pattern in FileSearchPatterns)
            {
                FileInfo[] files = directoryInfo.GetFiles(pattern);
                foreach (FileInfo file in files)
                {
                    lines += GetFileLineCount(file);
                    filesDone++;
                }
            }

            OnFilesCompleted(filesDone);
            return lines;
        }

        protected void OnFilesCompleted(int filesCompleted)
        {
            if (FilesCompleted != null && filesCompleted != 0)
                FilesCompleted(this, filesCompleted);
        }

        /// <summary>
        /// Gets the line count for a single file
        /// </summary>
        /// <param name="fi"></param>
        /// <returns></returns>
        public int GetFileLineCount(FileInfo fi)
        {
            int lines = 0;
            try
            {
                StreamReader reader = fi.OpenText();
                while (reader.ReadLine() != null)
                    lines++;
            }
            catch
            {
            }

            return lines;
        }

        private void dlc_FilesCompleted(object sender, int filesCompleted)
        {
            OnFilesCompleted(filesCompleted);
        }

        public int CompareTo(object obj)
        {
            if (obj is DirectoryLineCounter other)
            {
                return -TotalLines.CompareTo(other.TotalLines);
            }
            return 0;
        }
    }

    public delegate void FilesCompletedHandler(object sender, int filesCompleted);
}
